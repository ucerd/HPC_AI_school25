#!/usr/bin/env python3

import torch
from transformers import pipeline
import sys
import os

def main():
    model_path = "/mnt/lustre/nabeel/kamran/llama3.2-3b-instruct"
    
    if not os.path.exists(model_path):
        print(f"Error: Model not found at {model_path}")
        sys.exit(1)
    
    print("Loading model...")
    pipe = pipeline(
        "text-generation",
        model=model_path,
        torch_dtype=torch.bfloat16,
        device_map="auto",
    )
    print("Model loaded!")
    
    
    # Interactive mode
    print("\n--- Chat Mode ---")
    print("Type 'quit' to exit")
    
    while True:
        try:
            user_input = input("\nYou: ").strip()
            
            if user_input.lower() in ['quit', 'exit']:
                break
            if not user_input:
                continue
            
            # Generate response
            messages = [{"role": "user", "content": user_input}]
            
            result = pipe(
                messages,
                max_new_tokens=500,
                do_sample=False,  # Greedy decoding for consistency
                pad_token_id=pipe.tokenizer.eos_token_id
            )
            
            response = result[0]["generated_text"][-1]["content"]
            print(f"Assistant: {response}")
            
        except KeyboardInterrupt:
            break
        except EOFError:
            break
    
    print("Goodbye!")

if __name__ == "__main__":
    main()