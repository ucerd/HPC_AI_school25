import os
import torch
import torch.distributed as dist
import torch.nn as nn
import torch.optim as optim
from torch.distributed.fsdp import FullyShardedDataParallel as FSDP
from torch.distributed.fsdp import MixedPrecision, BackwardPrefetch
from torch.utils.data import DataLoader, DistributedSampler, Dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, get_linear_schedule_with_warmup
import time
import socket
import traceback
import json
from pathlib import Path

# Configuration for TinyLlama testing
MODEL_PATH = "/mnt/lustre/nabeel/kamran/TinyLlama-1.1B-Chat-v1.0"
DATA_PATH = "/mnt/lustre/nabeel/kamran/data"
BATCH_SIZE = 2 
GRADIENT_ACCUMULATION_STEPS = 4 
EPOCHS = 1  
LR = 5e-6  
WARMUP_STEPS = 50 
MAX_SEQ_LEN = 1024  
MAX_SAMPLES = 500  
def setup(rank, world_size):
    """Initialize distributed training"""
    os.environ['MASTER_ADDR'] = os.environ.get('MASTER_ADDR', '192.168.20.15')
    os.environ['MASTER_PORT'] = os.environ.get('MASTER_PORT', '29500')

    # Set network interfaces
    hostname = socket.gethostname()
    if hostname == 'master-node':
        os.environ['NCCL_SOCKET_IFNAME'] = 'ens1f1'
    elif hostname == 'node01':
        os.environ['NCCL_SOCKET_IFNAME'] = 'ens1f1'
    elif hostname == 'node02':
        os.environ['NCCL_SOCKET_IFNAME'] = 'ens1f0np0'
    elif hostname == 'node03':
        os.environ['NCCL_SOCKET_IFNAME'] = 'ens1f1'
    elif hostname == 'node04':
        os.environ['NCCL_SOCKET_IFNAME'] = 'ens1f0'
    elif hostname == 'node05':
        os.environ['NCCL_SOCKET_IFNAME'] = 'ens1f0np0'
    
    # Disable InfiniBand
    os.environ['NCCL_IB_DISABLE'] = '1'
    os.environ['NCCL_TIMEOUT'] = '600'  # 10 minutes
    
    dist.init_process_group(
        backend="nccl",
        rank=rank,
        world_size=world_size,
        timeout=torch.distributed.default_pg_timeout
    )
    
    # Set device
    local_rank = int(os.environ.get('SLURM_LOCALID', 0))
    torch.cuda.set_device(local_rank)
    device = torch.device(f"cuda:{local_rank}")
    
    return device

def cleanup():
    """Clean up distributed training"""
    try:
        dist.destroy_process_group()
    except:
        pass

def get_memory_usage():
    """Get current GPU memory usage"""
    if torch.cuda.is_available():
        allocated = torch.cuda.memory_allocated() / 1024**3
        total = torch.cuda.get_device_properties(0).total_memory / 1024**3
        return f"{allocated:.1f}GB/{total:.1f}GB"
    return "No CUDA"

class TextDataset(Dataset):
    """Custom dataset class for loading JSONL text data"""
    
    def __init__(self, data_path, tokenizer, max_seq_len=1024, max_samples=None):
        self.tokenizer = tokenizer
        self.max_seq_len = max_seq_len
        self.texts = []
        
        # Load data 
        data_dir = Path(data_path)
        
        jsonl_files = ['train.jsonl', 'validation.jsonl', 'test.jsonl']
        loaded_files = []
        
        for filename in jsonl_files:
            file_path = data_dir / filename
            if file_path.exists():
                print(f"Loading data from {file_path}")
                with open(file_path, 'r', encoding='utf-8') as f:
                    count = 0
                    for line in f:
                        if max_samples and len(self.texts) >= max_samples:
                            break
                        try:
                            data = json.loads(line.strip())
                            text = data.get('text', '').strip()
                            if text and len(text) > 50:  # Filter very short texts
                                self.texts.append(text)
                                count += 1
                        except json.JSONDecodeError:
                            continue
                loaded_files.append(f"{filename}: {count} samples")
                
                if max_samples and len(self.texts) >= max_samples:
                    break
        
        print(f"Dataset loaded: {len(self.texts)} total samples")
        print(f"Files loaded: {', '.join(loaded_files)}")
    
    def __len__(self):
        return len(self.texts)
    
    def __getitem__(self, idx):
        text = self.texts[idx]
        
        # Tokenize the text
        encoding = self.tokenizer(
            text,
            truncation=True,
            padding='max_length',
            max_length=self.max_seq_len,
            return_tensors='pt'
        )
        
        input_ids = encoding['input_ids'].squeeze()
        attention_mask = encoding['attention_mask'].squeeze()
        
        # For causal language modeling, labels = input_ids
        labels = input_ids.clone()
        
        return {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'labels': labels
        }

def save_fsdp_model(fsdp_model, tokenizer, save_path, rank):
    """Save FSDP model using sharded checkpointing"""
    try:
        import torch.distributed.checkpoint as dist_cp
    except ImportError:
        print("torch.distributed.checkpoint not available, using simple save...")
        if rank == 0:
            os.makedirs(save_path, exist_ok=True)
            torch.save(fsdp_model.state_dict(), os.path.join(save_path, "model.bin"))
            tokenizer.save_pretrained(save_path)
            print("Simple save completed")
        return True
    
    from torch.distributed.fsdp import StateDictType
    
    # Create checkpoint directory
    os.makedirs(save_path, exist_ok=True)
    checkpoint_dir = os.path.join(save_path, "sharded_checkpoint")
    
    try:
        print("Saving sharded checkpoint...")
        
        # Use sharded state dict
        with FSDP.state_dict_type(fsdp_model, StateDictType.SHARDED_STATE_DICT):
            state_dict = {"model": fsdp_model.state_dict()}
        
        # Save using distributed checkpoint
        dist_cp.save_state_dict(
            state_dict=state_dict,
            storage_writer=dist_cp.FileSystemWriter(checkpoint_dir),
        )
        
        print("Sharded checkpoint saved successfully")
        
        # converts to HuggingFace format
        if rank == 0:
            print("Converting to HuggingFace format...")
            try:
                from transformers import AutoModelForCausalLM
                temp_model = AutoModelForCausalLM.from_pretrained(
                    "/mnt/lustre/nabeel/kamran/TinyLlama-1.1B-Chat-v1.0",
                    torch_dtype=torch.float32,
                    low_cpu_mem_usage=True,
                )
                
                # Load sharded checkpoint into temp model
                temp_state_dict = {"model": temp_model.state_dict()}
                dist_cp.load_state_dict(
                    state_dict=temp_state_dict,
                    storage_reader=dist_cp.FileSystemReader(checkpoint_dir),
                    no_dist=True  # Load on single rank
                )
                temp_model.load_state_dict(temp_state_dict["model"])
                
                # Save in HuggingFace format
                hf_path = os.path.join(save_path, "huggingface_model")
                temp_model.save_pretrained(hf_path, safe_serialization=True)
                tokenizer.save_pretrained(hf_path)
                
                print(f"HuggingFace model saved to: {hf_path}")
                
                # Clean up temp model
                del temp_model
                torch.cuda.empty_cache()
                
            except Exception as hf_error:
                print(f"HuggingFace conversion failed: {hf_error}")
                print("Sharded checkpoint is still available")
        
        return True
        
    except Exception as e:
        print(f"Checkpoint save failed: {e}")
        return False

def main():
    rank = 0
    world_size = 1
    device = None
    
    try:
        # Initialize distributed environment
        rank = int(os.environ['RANK'])
        world_size = int(os.environ['WORLD_SIZE'])
        device = setup(rank, world_size)
        
        if rank == 0:
            print("=" * 60)
            print("TinyLlama Distributed Training Test")
            print("=" * 60)
            print(f"Starting distributed training on {world_size} GPUs")
            print(f"Model: {MODEL_PATH}")
            print(f"Data: {DATA_PATH}")
            print(f"Batch size per GPU: {BATCH_SIZE}")
            print(f"Gradient accumulation steps: {GRADIENT_ACCUMULATION_STEPS}")
            print(f"Effective batch size: {BATCH_SIZE * GRADIENT_ACCUMULATION_STEPS * world_size}")
            print(f"Epochs: {EPOCHS} (testing)")
            print(f"Max sequence length: {MAX_SEQ_LEN}")
            print(f"Max samples: {MAX_SAMPLES}")
        
        # Load model and tokenizer
        if rank == 0:
            print("Loading TinyLlama model and tokenizer...")
        
        tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        
        # Load TinyLlama model with memory optimizations
        model = AutoModelForCausalLM.from_pretrained(
            MODEL_PATH,
            torch_dtype=torch.float32,
            low_cpu_mem_usage=True,
        )
        
        # Enable gradient checkpointing to save memory
        model.gradient_checkpointing_enable()
        
        # Move model to device before wrapping with FSDP
        model = model.to(device)
        
        if rank == 0:
            print(f"TinyLlama model loaded. Memory usage: {get_memory_usage()}")
            print(f"Model parameters: {sum(p.numel() for p in model.parameters()) / 1e6:.1f}M")
        
        from transformers.models.llama.modeling_llama import LlamaDecoderLayer
        
        def auto_wrap_policy(module, recurse, nonwrapped_numel):
            if isinstance(module, LlamaDecoderLayer):
                return True
            return False
        
        # Configure mixed precision
        mixed_precision_policy = MixedPrecision(
            param_dtype=torch.float32,
            reduce_dtype=torch.float32,
            buffer_dtype=torch.float32,
        )
        
        # Wrap model with FSDP
        fsdp_model = FSDP(
            model,
            auto_wrap_policy=auto_wrap_policy,
            mixed_precision=mixed_precision_policy,
            device_id=device,
            sharding_strategy=torch.distributed.fsdp.ShardingStrategy.FULL_SHARD,
            backward_prefetch=BackwardPrefetch.BACKWARD_PRE,
            forward_prefetch=True,
            limit_all_gathers=True,
        )
        
        if rank == 0:
            print(f"FSDP model created. Memory usage: {get_memory_usage()}")
        
        # Create dataset and dataloader
        if rank == 0:
            print("Loading dataset...")
        
        dataset = TextDataset(
            data_path=DATA_PATH,
            tokenizer=tokenizer,
            max_seq_len=MAX_SEQ_LEN,
            max_samples=MAX_SAMPLES
        )
        
        sampler = DistributedSampler(
            dataset,
            num_replicas=world_size,
            rank=rank,
            shuffle=True,
        )
        
        dataloader = DataLoader(
            dataset,
            batch_size=BATCH_SIZE,
            sampler=sampler,
            num_workers=2,
            pin_memory=True,
        )
        
        if rank == 0:
            print(f"Dataset loaded: {len(dataset)} samples")
            print(f"Dataloader: {len(dataloader)} batches per epoch")
        
        # Setup optimizer and scheduler with gradient clipping
        optimizer = optim.AdamW(
            fsdp_model.parameters(),
            lr=LR,
            weight_decay=0.01,
            eps=1e-8,  # Prevent division by zero
        )
        
        total_steps = len(dataloader) * EPOCHS // GRADIENT_ACCUMULATION_STEPS
        scheduler = get_linear_schedule_with_warmup(
            optimizer,
            num_warmup_steps=WARMUP_STEPS,
            num_training_steps=total_steps,
        )
        
        if rank == 0:
            print(f"Training setup complete. Total steps: {total_steps}")
            print("Starting training...")
            print("-" * 60)
        
        # Training loop 
        fsdp_model.train()
        global_step = 0
        start_time = time.time()
        
        for epoch in range(EPOCHS):
            sampler.set_epoch(epoch)
            epoch_loss = 0.0
            valid_steps = 0
            optimizer.zero_grad()
            
            if rank == 0:
                print(f"\nEpoch {epoch+1}/{EPOCHS}")
            
            for step, batch in enumerate(dataloader):
                try:
                    # Move batch to device
                    input_ids = batch['input_ids'].to(device)
                    attention_mask = batch['attention_mask'].to(device)
                    labels = batch['labels'].to(device)
                    
                    # Debug: Check for invalid inputs
                    if rank == 0 and step == 0 and epoch == 0:
                        print(f"Input shape: {input_ids.shape}, range: [{input_ids.min().item()}, {input_ids.max().item()}]")
                    
                    # Forward pass
                    outputs = fsdp_model(
                        input_ids=input_ids,
                        attention_mask=attention_mask,
                        labels=labels,
                    )
                    loss = outputs.loss
                    
                    # Check for NaN/infinite loss
                    if torch.isnan(loss) or torch.isinf(loss):
                        if rank == 0:
                            print(f"WARNING: Invalid loss at step {step}: {loss.item()}")
                        continue
                    
                    loss = loss / GRADIENT_ACCUMULATION_STEPS
                    
                    # Backward pass
                    loss.backward()
                    
                    # Gradient accumulation
                    if (step + 1) % GRADIENT_ACCUMULATION_STEPS == 0:
                        # Check gradients for NaN/inf before clipping
                        grad_norm = fsdp_model.clip_grad_norm_(max_norm=1.0)
                        
                        if torch.isnan(grad_norm) or torch.isinf(grad_norm):
                            if rank == 0:
                                print(f"WARNING: Invalid gradients. Skipping step.")
                            optimizer.zero_grad()
                            continue
                        
                        # Optimizer step
                        optimizer.step()
                        scheduler.step()
                        optimizer.zero_grad()
                        
                        global_step += 1
                        
                        # Logging with more debug info
                        if rank == 0 and global_step % 5 == 0:
                            elapsed = time.time() - start_time
                            current_loss = loss.item() * GRADIENT_ACCUMULATION_STEPS
                            print(f"Step {global_step}/{total_steps} | "
                                  f"Loss: {current_loss:.4f} | "
                                  f"Grad Norm: {grad_norm:.4f} | "
                                  f"LR: {scheduler.get_last_lr()[0]:.2e} | "
                                  f"Memory: {get_memory_usage()} | "
                                  f"Time: {elapsed:.1f}s")
                    
                    if not (torch.isnan(loss) or torch.isinf(loss)):
                        epoch_loss += loss.item() * GRADIENT_ACCUMULATION_STEPS
                        valid_steps += 1
                
                except Exception as e:
                    if rank == 0:
                        print(f"Error in step {step}: {e}")
                    continue
            
            # End of epoch
            avg_loss = epoch_loss / max(valid_steps, 1)  # Avoid division by zero
            if rank == 0:
                elapsed = time.time() - start_time
                print(f"Epoch {epoch+1} completed | Average loss: {avg_loss:.4f} | Valid steps: {valid_steps}/{len(dataloader)} | Time: {elapsed:.1f}s")
        
        if world_size > 1:
            print(f"Rank {rank}: Waiting for all processes before saving...")
            dist.barrier()
        
        # Save model checkpoint
        print(f"\nRank {rank}: Starting save process...")
        save_path = os.path.join(MODEL_PATH, "fsdp_checkpoint")
        
        success = save_fsdp_model(fsdp_model, tokenizer, save_path, rank)
        
        # Wait for all ranks to finish saving
        if world_size > 1:
            dist.barrier()
        
        # Final status report (rank 0 only)
        if rank == 0:
            total_time = time.time() - start_time
            print(f"Total training time: {total_time:.1f}s")
            
            if success:
                print("Training and saving completed successfully!")
                print(f"Sharded checkpoint: {save_path}/sharded_checkpoint/")
                print(f"HuggingFace model: {save_path}/huggingface_model/")
            else:
                print("Training completed but saving failed.")
        
        # Final synchronization
        if world_size > 1:
            dist.barrier()
            time.sleep(2)  # Small delay to ensure clean shutdown
    
    except Exception as e:
        print(f"Rank {rank} error: {e}")
        traceback.print_exc()
        if world_size > 1:
            try:
                dist.barrier()
            except:
                pass
        raise
    
    finally:
        # Ensure cleanup happens even if there's an error
        if world_size > 1:
            try:
                dist.barrier()
            except:
                pass
        cleanup()

if __name__ == "__main__":
    main()