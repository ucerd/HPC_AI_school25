import os
import torch
import torch.distributed as dist
import time
import socket
from transformers import AutoTokenizer, AutoModelForCausalLM

# Config
MODEL_PATH = "/mnt/lustre/nabeel/kamran/llama3.2-3b-instruct"
MAX_TOKENS = 100
TEMPERATURE = 0.7

def log(message):
    hostname = socket.gethostname()
    rank = int(os.environ.get('RANK', 0))
    print(f"[{hostname}:R{rank}] {message}", flush=True)

def get_memory_usage():
    if torch.cuda.is_available():
        allocated = torch.cuda.memory_allocated(0) / 1024**3
        total = torch.cuda.get_device_properties(0).total_memory / 1024**3
        return f"{allocated:.1f}GB/{total:.1f}GB"
    return "No CUDA"

def setup_distributed():
    rank = int(os.environ['RANK'])
    world_size = int(os.environ['WORLD_SIZE'])
    
    # Set GPU device
    local_rank = int(os.environ.get('SLURM_LOCALID', 0))
    torch.cuda.set_device(local_rank)
    device = torch.device(f'cuda:{local_rank}')
    
    log(f"Setting up distributed: rank={rank}, world_size={world_size}")
    
    try:
        dist.init_process_group(backend="nccl", rank=rank, world_size=world_size)
        log("NCCL setup complete")
        return rank, world_size, device
    except Exception as e:
        log(f"Setup failed: {e}")
        return None, None, None

def load_model(device):
    """Load full model"""
    log(f"Memory before loading: {get_memory_usage()}")
    
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, local_files_only=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH,
        torch_dtype=torch.float16,
        device_map=device,
        local_files_only=True
    )
    
    log(f"Memory after loading: {get_memory_usage()}")
    return model, tokenizer

def process_prompts(model, tokenizer, prompts, device):
    """Process assigned prompts"""
    results = []
    
    for i, prompt in enumerate(prompts):
        log(f"Processing prompt {i+1}: '{prompt}'")
        
        start_time = time.time()
        
        # Generate response
        inputs = tokenizer(prompt, return_tensors="pt")
        inputs = {k: v.to(device) for k, v in inputs.items()}
        
        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=MAX_TOKENS,
                do_sample=True,
                temperature=TEMPERATURE,
                pad_token_id=tokenizer.eos_token_id
            )
        
        full_text = tokenizer.decode(outputs[0], skip_special_tokens=True)
        response = full_text[len(prompt):].strip()
        
        generation_time = time.time() - start_time
        tokens = len(tokenizer.encode(response))
        
        result = {
            'prompt': prompt,
            'response': response,
            'tokens': tokens,
            'time': generation_time,
            'speed': tokens / generation_time if generation_time > 0 else 0
        }
        
        results.append(result)
        print(f"Response: {response}")
        print(f"Stats: {tokens} tokens, {result['speed']:.2f} tok/s\n")
    
    return results

def main():
    rank, world_size, device = setup_distributed()
    
    if rank is None or world_size != 2:
        log(f"Expected 2 nodes, got {world_size}")
        return
    
    # Load model
    model, tokenizer = load_model(device)
    
    # Test prompts
    all_prompts = [
        "What is artificial intelligence?",
        "How do neural networks work?",
        "Explain machine learning simply.",
        "What is distributed computing?",
        "How do transformers work?"
    ]
    
    # Split prompts between 2 nodes
    if rank == 0:
        my_prompts = all_prompts[:3]  # First 3 prompts
    else:
        my_prompts = all_prompts[3:]  # Last 2 prompts
    
    log(f"Processing {len(my_prompts)} prompts")
    
    # Sync before starting
    dist.barrier()
    
    if rank == 0:
        print("\n" + "="*50)
        print("2-NODE DATA PARALLEL TEST")
        print("="*50)
        print(f"Node 0: prompts 1-3")
        print(f"Node 1: prompts 4-5")
        print("="*50)
    
    # Process prompts
    start_time = time.time()
    results = process_prompts(model, tokenizer, my_prompts, device)
    processing_time = time.time() - start_time
    
    # Wait for both nodes
    dist.barrier()
    
    # Gather all results
    all_results = [None] * world_size
    dist.all_gather_object(all_results, results)
    
    if rank == 0:
        # Print summary
        print("\n" + "="*50)
        print("RESULTS SUMMARY")
        print("="*50)
        
        total_tokens = 0
        total_gen_time = 0
        
        for node_rank, node_results in enumerate(all_results):
            if node_results:
                node_tokens = sum(r['tokens'] for r in node_results)
                node_time = sum(r['time'] for r in node_results)
                total_tokens += node_tokens
                total_gen_time += node_time
                
                print(f"Node {node_rank}: {len(node_results)} prompts, {node_tokens} tokens, {node_time:.2f}s")
        
        print(f"Total: {total_tokens} tokens")
        print(f"Parallel time: {processing_time:.2f}s")
        print(f"Sequential time would be: {total_gen_time:.2f}s")
        print(f"Speedup: {total_gen_time/processing_time:.2f}x")
        print("="*50)
    
    # Cleanup
    log(f"Final memory: {get_memory_usage()}")
    dist.destroy_process_group()
    log("Test completed")

if __name__ == "__main__":
    main()